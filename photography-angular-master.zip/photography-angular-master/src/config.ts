export const config = {
    API_URL : "https://42a8dc5458ad.ngrok.io/api/v1",
 }