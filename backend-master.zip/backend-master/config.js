const dotenv = require('dotenv');
dotenv.config();
 const config = {
    user : process.env.DBUSER,
    pass : process.env.PASS,
    port :process.env.PORT,
    db:process.env.DB
 };
module.exports = config;