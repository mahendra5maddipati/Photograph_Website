"use strict";
var dbConn = require("../configs/db.config");
//About object create
var mediumInfo = function (data) {
  this.id =  data.id;
  this.medium = data.medium;
  this.links =  data.links;
  this.created_at = data.created_at;
  this.updated_at = data.updated_at;
};

mediumInfo.getDetails = function (id, result) {
  dbConn.query(
    "Select * from social_media",
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(err, null);
      } else {
        result(null, res);
      }
    }
  );
};


module.exports = mediumInfo;
