"use strict";
var dbConn = require("../configs/db.config");
//About object create
var AboutInfo = function (data) {
  this.id =  data.id;
  this.type = data.type;
  this.text =  data.text;
  this.created_at = data.created_at;
  this.updated_at = data.updated_at;
};

AboutInfo.getDetails = function (id, result) {
  dbConn.query(
    "Select * from about",
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(err, null);
      } else {
        result(null, res);
      }
    }
  );
};

AboutInfo.update = function (id, employee, result) {
  dbConn.query(
    "UPDATE employees SET first_name=?,last_name=?,email=?,phone=?,organization=?,designation=?,salary=? WHERE id = ?",
    [
      employee.first_name,
      employee.last_name,
      employee.email,
      employee.phone,
      employee.organization,
      employee.designation,
      employee.salary,
      id,
    ],
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(null, err);
      } else {
        console.log("suscc: ", res);
        result(null, res);
      }
    }
  );
};

module.exports = AboutInfo;
