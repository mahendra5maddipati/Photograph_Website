"use strict";
var dbConn = require("../configs/db.config");
//About object create
var contactInfo = function (data) {
    this.id =  data.id;
    this.type = data.type;
    this.details =  data.details;
    this.created_at = data.created_at;
    this.updated_at = data.updated_at;
};

contactInfo.getDetails = function (id, result) {
  dbConn.query(
    "Select * from contact",
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(err, null);
      } else {
        result(null, res);
      }
    }
  );
};


module.exports = contactInfo;
