"use strict";
var dbConn = require("../configs/db.config");
//About object create
var tipsInfo = function (data) {
    this.id =  data.id;
    this.type = data.type;
    this.text =  data.text;
    this.created_at = data.created_at;
    this.updated_at = data.updated_at;
};

tipsInfo.getDetails = function (id, result) {
  dbConn.query(
    "Select * from tips",
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(err, null);
      } else {
        result(null, res);
      }
    }
  );
};


module.exports = tipsInfo;
