"use strict";
var dbConn = require("../configs/db.config");
//About object create

var Messages = function (data) {
    this.id = data.id;
    this.name = data.name;
    this.email = data.email;
    this.subject = data.subject;
    this.message = data.message;
    this.created_at = data.created_at;
    this.updated_at = data.updated_at;
};

Messages.getAllMessages = function (id, result) {
    dbConn.query("Select * from messages", function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        } else {
            result(null, res);
        }
    });
};

Messages.create = function (newMsg, result) {
    dbConn.query("INSERT INTO messages set ?", newMsg, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        } else {
            console.log(res.insertId);
            result(null, res.insertId);
        }
    });
};

Messages.findById = function (id, result) {
    dbConn.query(
        "Select * from messages where id = ? ",
        id,
        function (err, res) {
            if (err) {
                console.log("error: ", err);
                result(err, null);
            } else {
                result(null, res);
            }
        }
    );
};

Messages.delete = function (id, result) {
    dbConn.query("DELETE FROM messages WHERE id = ?", [id], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            result(null, res);
        }
    });
};

Messages.update = function (id, message, result) {
    dbConn.query("UPDATE messages SET first_name=?,last_name=?,email=?,phone=?,organization=?,designation=?,salary=? WHERE id = ?",
     [message.first_name, message.last_name, message.email, message.phone, message.organization, message.designation, message.salary, id], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        } else {
            result(null, res);
        }
    });
};

module.exports = Messages;
