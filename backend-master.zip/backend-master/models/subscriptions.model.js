"use strict";
var dbConn = require("../configs/db.config");
//About object create

var Subscription = function (data) {
    this.id = data.id;
    this.email = data.email;
    this.sentMail = data.sentMail;
    this.created_at = data.created_at;
    this.updated_at = data.updated_at;
};
Subscription.getAllSubscriptions = function (id, result) {
    dbConn.query("Select * from subscriptions", function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        } else {
            result(null, res);
        }
    });
};

Subscription.create = async  function (newSub, result) {
    dbConn.query("INSERT INTO subscriptions set ?", newSub, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        } else {
            console.log(res.insertId);
            result(null, res.insertId);
        }
    });
};


module.exports = Subscription;