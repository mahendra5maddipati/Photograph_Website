const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
// create express app
const app = express();
app.use(cors());
const config = require('./config');
const port = config.port || 5000;
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.get('/', (req, res) => {
  res.send("Hello World");
});


const aboutInfoRoutes = require('./routes/about.routes');
const mediumInfoRoutes =  require('./routes/medium.routes');
const tipsInfoRoutes =  require('./routes/tips.routes');
const contactInfoRoutes =  require('./routes/contact.routes');
const messagesRoutes =  require('./routes/messages.routes');
const subscriptionsRoutes =  require('./routes/subscription.routes');




// using as middleware
app.use('/api/v1/about', aboutInfoRoutes)
app.use('/api/v1/media', mediumInfoRoutes)
app.use('/api/v1/tips', tipsInfoRoutes)
app.use('/api/v1/contact', contactInfoRoutes)
app.use('/api/v1/messages', messagesRoutes)
app.use('/api/v1/subscriptions', subscriptionsRoutes)




// listen for requests
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
