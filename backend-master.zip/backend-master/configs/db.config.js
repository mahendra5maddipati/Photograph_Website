'use strict';
const mysql = require('mysql');
const {user,pass,db}  = require('../config.js');
//local mysql db connection
// console.log("coocooc",user,pass)
const dbConn = mysql.createConnection({
  host     : 'localhost',
  user     : user,
  port : 3306,
  password : pass,
  database : db
});
dbConn.connect(function(err) {
  if (err) throw err;
  console.log("Database Connected!");
});
module.exports = dbConn;