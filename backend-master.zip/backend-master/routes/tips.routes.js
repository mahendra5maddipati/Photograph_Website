const express = require('express')
const router = express.Router()
const tipsController =   require('../controllers/tips.controller');
// Retrieve all employees
router.get('/', tipsController.getDetails);
module.exports = router