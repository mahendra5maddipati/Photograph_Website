const express = require('express')
const router = express.Router()
const mediumController =   require('../controllers/medium.controller');
// Retrieve all employees
router.get('/', mediumController.getDetails);
module.exports = router