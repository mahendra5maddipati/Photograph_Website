const express = require('express')
const router = express.Router()
const contactController =   require('../controllers/contact.controller');
// Retrieve all employees
router.get('/', contactController.getDetails);
module.exports = router