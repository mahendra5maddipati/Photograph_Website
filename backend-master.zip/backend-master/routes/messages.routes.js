const express = require('express')
const router = express.Router()
const messagesController =   require('../controllers/messages.controller');
// Retrieve all employees
router.get('/', messagesController.getAllMessages);
router.get('/:id', messagesController.findById);

// Create a new message
router.post('/', messagesController.create);


// // Update a message with id
// router.put('/:id', messagesController.update);
// // Delete a message with id
router.delete('/:id', messagesController.delete);

module.exports = router