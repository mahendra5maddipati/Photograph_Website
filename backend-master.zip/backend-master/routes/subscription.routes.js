const express = require('express')
const router = express.Router()
const subscriptionController =   require('../controllers/subscription.controller');
// Retrieve all employees
router.get('/', subscriptionController.getAllSubscriptions);
// router.get('/:id', subscriptionController.findById);

// Create a new message
router.post('/', subscriptionController.create);


// // Update a message with id
// router.put('/:id', messagesController.update);
// // Delete a message with id
// router.delete('/:id', messagesController.delete);

module.exports = router