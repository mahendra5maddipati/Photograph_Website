console.log(`Your port is ${process.env.DBUSER}`); // undefined
const dotenv = require('dotenv');
dotenv.config();
console.log(`Your port is ${process.env.DBUSER}`);
console.log(`Your port is ${process.env.PASS}`);