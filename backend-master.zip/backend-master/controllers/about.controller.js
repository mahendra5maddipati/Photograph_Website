'use strict';
const AboutInfo = require('../models/about.model');


exports.getDetails = function(req, res) {
  AboutInfo.getDetails(req, function(err, info) {
  if (err)
    res.send(err);
  res.json(info);
});
};
exports.update = function(req, res) {
  if(req.body.constructor === Object && Object.keys(req.body).length === 0){
    res.status(400).send({ error:true, message: 'Please provide all required field' });
  }else{
    AboutInfo.update(req.params.id, new Employee(req.body), function(err, aboutInfo) {
   if (err)
    res.send(err);
   res.json({ error:false, message: 'Employee successfully updated' });
});
}
};
