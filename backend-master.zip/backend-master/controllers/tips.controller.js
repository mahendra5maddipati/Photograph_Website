'use strict';
const tipsInfo = require('../models/tips.model');


exports.getDetails = function(req, res) {
  tipsInfo.getDetails(req, function(err, info) {
  if (err)
    res.send(err);
  res.json(info);
});
};