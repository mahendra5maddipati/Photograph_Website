'use strict';
const contactInfo = require('../models/contact.model');


exports.getDetails = function(req, res) {
    contactInfo.getDetails(req, function(err, info) {
  if (err)
    res.send(err);
  res.json(info);
});
};