"use strict";
const Subscription = require("../models/subscriptions.model");

exports.getAllSubscriptions = function (req, res) {
    Subscription.getAllSubscriptions(req, function (err, info) {
        if (err) res.send(err);
        res.json(info);
    });
};


exports.create = function (req, res) {
    req.body = {...req.body,sentMail :0,created_at:new Date(),updated_at:new Date()}
    const new_sub = new Subscription(req.body);
    //handles null error
    if (req.body.constructor === Object && Object.keys(req.body).length === 0) {
        res
            .status(400)
            .send({ error: true, message: "Please provide all required field" });
    } else {
        Subscription.create(new_sub, function (err, message) {
            if (err) res.send(err);
            res.json({
                error: false,
                message: "Subscription added successfully!",
                data: message,
            });
        });
    }
};