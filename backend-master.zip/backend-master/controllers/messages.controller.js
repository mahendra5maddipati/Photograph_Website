"use strict";
const Messages = require("../models/messages.model");

exports.getAllMessages = function (req, res) {
    Messages.getAllMessages(req, function (err, info) {
        if (err) res.send(err);
        res.json(info);
    });
};

exports.findById = function (req, res) {
    Messages.findById(req.params.id, function (err, message) {
        if (err) res.send(err);
        res.json(message);
    });
};

exports.create = function (req, res) {
    req.body = {...req.body,created_at:new Date(),updated_at:new Date()}
    const new_message = new Messages(req.body);
    //handles null error
    if (req.body.constructor === Object && Object.keys(req.body).length === 0) {
        res
            .status(400)
            .send({ error: true, message: "Please provide all required field" });
    } else {
        Messages.create(new_message, function (err, message) {
            if (err) res.send(err);
            res.json({
                error: false,
                message: "Message added successfully!",
                data: message,
            });
        });
    }
};

exports.update = function (req, res) {
    if (req.body.constructor === Object && Object.keys(req.body).length === 0) {
        res
            .status(400)
            .send({ error: true, message: "Please provide all required field" });
    } else {
        Messages.update(
            req.params.id,
            new Messages(req.body),
            function (err, message) {
                if (err) res.send(err);
                res.json({ error: false, message: "Message successfully updated" });
            }
        );
    }


};

exports.delete = function (req, res) {
    Messages.delete(req.params.id, function (err, message) {
        if (err) res.send(err);
        res.json({ error: false, message: "Message successfully deleted" });
    });
};
