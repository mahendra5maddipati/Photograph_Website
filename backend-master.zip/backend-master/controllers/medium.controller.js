'use strict';
const mediumInfo = require('../models/medium.model');


exports.getDetails = function(req, res) {
  mediumInfo.getDetails(req, function(err, info) {
  if (err)
    res.send(err);
  res.json(info);
});
};
